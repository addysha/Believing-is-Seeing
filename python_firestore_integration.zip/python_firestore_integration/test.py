import firebase_admin
from firebase_admin import firestore, credentials
import logging 
from google.cloud.firestore import Client as FirestoreClient # importing the return type of firestore.client()
from datetime import datetime,timedelta
from pytz import timezone

# from shapely.geometry import Point
# from shapely.geometry.polygon import Polygon

cred = credentials.Certificate('python_firestore_integration\\cloud_key.json')
app = firebase_admin.initialize_app(cred)
db: FirestoreClient = firestore.client() # Addid



name_list = [
{
    "firstName" : "Edward",
    "lastName":"Wilson",
    "birthDate": datetime.now(timezone('NZ')) - timedelta(days=365*60),
    "isDead":False,
    "deathDate":None
},
{
    "firstName" : "addy",
    "lastName":"sharmap",
    "birthDate": datetime.now(timezone('NZ')) - timedelta(days=365*20),
    "isDead":True,
    "deathDate":datetime.now(timezone('NZ')) - timedelta(days=1)
}

]



for person in name_list:
    db.collection('TestCollection').add(person)

for doc in db.collection('TestCollection').limit(10).get():
    print(doc.id)
    print(doc._data)